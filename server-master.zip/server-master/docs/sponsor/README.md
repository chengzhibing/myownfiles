# Sponsor

This project is maintained by Francisco Presencia and is part of Francisco IO LTD (UK). It is a lot of work and I'd love if you or your company could help me keep building it and in the process I'll help you with Node.js.

**All sponsors will receive an ebook and/or a book** for free when released. Besides this, there are some sponsors tiers:

| sponsorship  | perk                           | credit (homepage + github)   |
|--------------|--------------------------------|------------------------------|
|  $1,000+     | email support                  | logo (normal) + link + ♥     |
|  $2,000+     | live coding help of 10h        | logo (normal) + link + ♥     |
| $10,000+     | in-person workshop of 20h      | logo (large) + link + ♥      |

<a class="button email">Get in touch</a>



## Notes and conditions

Donations are 0-99.99$ and sponsorships are 100$+.

All of the perks have a valid period of 1 year, later on they'd have to be renewed. The book/ebook has no duration and has to happen once.

I reserve the right to reject anything if I don't find it suitable, including but not limited to malign requests.

Everything in this page is negotiable and will be specified when getting in touch:

**Thank you a lot for helping me improve server.js!**

<a class="button email">Get in touch</a> <a href="https://www.paypal.me/franciscopresencia/" class="button">Paypal me</a>

# WEBSITE

This folder only contains the website: [**server** website](https://serverjs.io/)

You might be looking for the folder "Documentation": [**documentation folder**](documentation)

Which can also be accessed through the website: [**documentation in the website**](https://serverjs.io/documentation)

> Note: I've contacted Github about how ridiculous it is to have to name the *web* as *docs* and suggested that they allow the name... *web*. They answered quickly and said it was in their tasklog, so kudos :+1:.

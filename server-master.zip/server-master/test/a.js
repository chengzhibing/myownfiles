module.exports = ctx => '世界';

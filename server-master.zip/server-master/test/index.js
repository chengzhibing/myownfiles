// The test suite and the different needed parts
module.exports = {

  // Generate a random port that is not already in use
  port: require('./port'),

  // Handle a function that expects to be thrown
  // throws: require('./throws')
};

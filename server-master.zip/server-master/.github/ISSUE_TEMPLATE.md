### Description

<!-- Example: The server fails to find my route when requested. -->

### Expected outcome

<!-- Example: The server responds with a 200 and OK. -->

### Actual outcome

<!-- Example: The route returns a 404 and Not Found -->

### Live Demo

<!-- Example: https://glitch.com/edit/#!/remix/server-js-demo -->

### System Information

**OS:** MacOS High Sierra, Windows 10, etc.

**Node Version:** v8.9.1

**Server.js Version:** 1.0.14

const server = require('../../');

// Should log the { status: 404 } error in the console
server();
